#FBX Instant Exporter

import c4d
from c4d import gui
import os



def main():
    #c4d.gui.MessageDialog("1")
    # Get the Documents folder path
    #path = c4d.storage.LoadDialog(c4d.FILESELECTTYPE_IMAGES, "Select an Image")
    path = os.path.expanduser(r"~\Desktop")
    #c4d.gui.MessageDialog(desktop)

    # Specify the name of the FBX file you want to export
    file_name = "Test_Scene.fbx"
    #c4d.gui.MessageDialog("3")

    # Create the full export path by joining the folder path and file name
    export_path = os.path.join(path, file_name)
    #c4d.gui.MessageDialog("4")
    # Export the current document as an FBX file
    c4d.documents.SaveDocument(doc, export_path, c4d.SAVEDOCUMENTFLAGS_DONTADDTORECENTLIST, c4d.FORMAT_FBX_EXPORT)


    # Display a message dialog to inform the user
    message = f"FBX file exported to:\n{export_path}"
    c4d.gui.MessageDialog(message)

# Check if a document is open
doc = c4d.documents.GetActiveDocument()
if doc is not None:
    # Execute the main function
    main()
else:
    c4d.gui.MessageDialog("No Cinema 4D document is open.")